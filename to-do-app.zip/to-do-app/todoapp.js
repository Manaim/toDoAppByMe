let theForm = document.getElementById("theForm")
let theField = document.getElementById("theField")
let theList = document.getElementById("theList")

theForm.addEventListener("submit" ,(m) => {
    m.preventDefault()
    createItem(theField.value)
    
})

function createItem(p) {
    let theHTML = `<li> ${p} <button onclick= "deleteItem(this)" >Delete</button> </li>`
    theList.insertAdjacentHTML("beforeend", theHTML)
    theField.value = ""
    theField.focus()
}

function deleteItem (elementToDelete) {
    elementToDelete.parentElement.remove()
}